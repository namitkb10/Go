package folder2Practice

import "fmt"

func SumOfDigits() {
	fmt.Print("Enter a four digits Number: ")
	var intNumber int
	var sum1 int
	var newNumber int
	fmt.Scanln(&intNumber)

	for intNumber > 0 {
		newNumber = intNumber % 10
		sum1 = sum1 + newNumber
		intNumber = intNumber / 10
	}

	fmt.Println("Sum of Entered Number is: ", sum1)

}
