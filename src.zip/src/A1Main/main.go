package main

import (
	"bufio"
	"fmt"
	"os"
)

func main() {
	fmt.Println(("Welcome to Main"))
	//A1Practice.SumOfDigits()
	//A1Practice.CheckLeapYear()
	//A1Practice.SingleNumberFunction()
	//A1Practice.DoubleNumberFunction()
	//A1Practice.ReadString()
	//A1Practice.Concate2String()
	fmt.Print("Enter the Valid String: ")
	var str string
	fmt.Scanln(&str)

	// Length of the given string
	length := len(str)
	fmt.Println("Max Length of String is: ", length)

	// Last character in the given string
	lastCharacter := str[len(str)-1:]
	fmt.Println("Last Character Of String is: ", lastCharacter)

	// Print the Ascii value of each character in the given string
	reader := bufio.NewReader(os.Stdin)

	fmt.Print("Enter Any String to find ASCII Values = ")
	strData, _ := reader.ReadString('\n')

	for i := 0; i < len(strData); i++ {
		fmt.Printf("The ASCII Value of %c = %d\n", strData[i], strData[i])
	}

	// Reverse of Entered String
	runee := []rune(str)
	var reverse []rune
	for i := len(runee) - 1; i >= 0; i-- {
		reverse = append(reverse, runee[i])
	}
	fmt.Println("Reverse Of Entered String is: ", string(reverse))
}
