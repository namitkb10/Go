package A1practice

import (
	"bufio"
	"fmt"
	"os"
)

func CheckLeapYear_1() {
	fmt.Print("Enter Some Valid Year: ")
	var leapYearNumber int
	fmt.Scanln(&leapYearNumber)

	// Check Entered Number is Leap Year OR Not
	if (leapYearNumber%4 == 0) && (leapYearNumber%100 != 0) || (leapYearNumber%400 == 0) {
		fmt.Println("Entered Number is a Leap Year")
	} else if leapYearNumber/4 != 0 {
		fmt.Println("Entered Number is not a Leap ")
	} else {
		fmt.Println("Entered Number is not a Valid Year Number")
	}
}

func SingleNumberFunction_2() {
	fmt.Print("Enter a Valid Number: ")
	var intNumber int
	fmt.Scanln(&intNumber)

	// Check Entered Number is Odd Number OR Even Number
	if intNumber%2 == 0 {
		fmt.Println("Entered Number is Even Number")
	} else if intNumber%2 != 0 {
		fmt.Println("Entered Number is Odd Number ")
	} else {
		fmt.Println("Entered Number is not a Valid Number")
	}

	// Check Entered Number is Positive Number OR Negative Number
	if intNumber > 0 {
		fmt.Println("Entered Number is a Positive Number")
	} else if intNumber < 0 {
		fmt.Println("Entered Number is a Negative Number")
	} else {
		fmt.Println("Entered Number is Zero")
	}

	// Check Entered Number is Single Digit Number OR Double Digit Number
	if (intNumber >= 0) && (intNumber <= 9) {
		fmt.Println("Entered Number is a Single Digit Number")
	} else if (intNumber >= 10) && (intNumber <= 99) {
		fmt.Println("Entered Number is a Double Digit Number")
	} else {
		fmt.Println("Entered Number is neither a Single Digit nor Double Digit Number")
	}
}

func DoubleNumberFunction_3() {
	fmt.Print("Enter First Valid Number: ")
	var intNumber1 int
	fmt.Scanln(&intNumber1)

	fmt.Print("Enter 2nd Valid Number: ")
	var intNumber2 int
	fmt.Scanln(&intNumber2)

	var sumNumber int
	var minusNumber int
	var divisionNumber int
	var multiplyNumber int

	// Check Sum of two Number
	sumNumber = intNumber1 + intNumber2
	fmt.Println("Sum of Entered Number is: ", sumNumber)

	// Check Substraction of two Number
	minusNumber = intNumber1 - intNumber2
	fmt.Println("Substraction of Entered Number is: ", minusNumber)

	// Check Division of two Number
	divisionNumber = intNumber1 / intNumber2
	fmt.Println("Division of Entered Number is: ", divisionNumber)

	// Check Multiplication of two Number
	multiplyNumber = intNumber1 * intNumber2
	fmt.Println("Multiplication of Entered Number is: ", multiplyNumber)
}

func ReadString_4() {
	fmt.Print("Enter the Valid String: ")
	var str string
	fmt.Scanln(&str)

	// Length of the given string
	length := len(str)
	fmt.Println("Max Length of String is: ", length)

	// Last character in the given string
	lastCharacter := str[len(str)-1:]
	fmt.Println("Last Character Of String is: ", lastCharacter)

	// Print the Ascii value of each character in the given string
	reader := bufio.NewReader(os.Stdin)

	fmt.Print("Enter Any String to find ASCII Values = ")
	strData, _ := reader.ReadString('\n')

	for i := 0; i < len(strData); i++ {
		fmt.Printf("The ASCII Value of %c = %d\n", strData[i], strData[i])
	}

	// Reverse the given string and print
	runee := []rune(str)
	var reverse []rune
	for i := len(runee) - 1; i >= 0; i-- {
		reverse = append(reverse, runee[i])
	}
	fmt.Println("Reverse Of Entered String is: ", string(reverse))
}

func Concate2String_5() {
	fmt.Println("Enter the First String: ")
	var str1 string
	fmt.Scanln(&str1)

	fmt.Println("Enter the Second String: ")
	var str2 string
	fmt.Scanln(&str2)

	fmt.Println("Concatenation of Entered String is: ", str1+" "+str2)
}
