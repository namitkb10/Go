package main

import (
	"fmt"
)

func main() {

	array_FirstLast := [5]int{10, 20, 30, 40, 50}

	// Printing the Array
	fmt.Printf("Given Arrays is: %v\n", array_FirstLast)

	// Accessing zeroth index
	// i.e. first element
	first := array_FirstLast[0]

	// Printing first element
	fmt.Printf("First Element Of an Arrays is: %d\n", first)

	// Accessing length(slice)-1
	// index i.e. last
	// element
	last := array_FirstLast[len(array_FirstLast)-1]

	// Printing last element
	fmt.Printf("Last Element Of an Arrays is: %v\n", last)
}

func EmployeeName_Slice() {
	// Take User Input and keep on entering untill Done is not entered
	// Using Slice Concepts

	var strName string = ""
	var employees []string

	fmt.Print("Enter Employee Name: ")
	fmt.Scan(&strName)
	for strName != "Done" {
		employees = append(employees, strName)

	}
	fmt.Print("Employee Names: ", employees)

}
