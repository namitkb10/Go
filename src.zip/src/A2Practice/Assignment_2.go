package A2Practice

import (
	"fmt"
	"math"
)

func IsPrime_1_A() {
	fmt.Print("Enter a Positive Number: ")
	var number int
	fmt.Scan(&number)

	var boolean bool

	for i := 2; i < number; i++ {
		if number%i == 0 {
			boolean = true
			break
		}
	}

	if boolean {
		fmt.Println("Entered Number is not a Prime Number")
	} else {
		fmt.Println("Entered Number is a Prime Number")
	}
}

func IsPalindrome_1_B() {
	fmt.Print("Enter a positive Number: ")
	var num int
	fmt.Scan(&num)
	var newNum int
	var remainder int
	var sum int = 0
	newNum = num

	if num > 0 {
		for num > 0 {
			remainder = num % 10
			sum = (sum * 10) + remainder
			num = num / 10

		}
	} else {
		fmt.Println("Entered Number is not a Valid Number")
	}

	if sum == newNum {
		fmt.Println("Entered Number is a Palindrome Number")
	} else {
		fmt.Println("Entered Number is Not a Palindrome Number")
	}
}

func sqrt_2_A() {
	fmt.Print("Enter a positive Number: ")
	var number1 float64
	fmt.Scan(&number1)
	if number1 < 0 {
		fmt.Println("Please Enter a Valid Number")
	} else {
		//var number2 int = math.sqrt(number1)
		// Using Sqrt() function
		res_1 := math.Sqrt(number1)
		//fmt.Println("Square Root Of Entered Number is:  %.1f", res_1)
		fmt.Println("Square root of Entered Number", number1, " is: ", res_1)
	}
}

func Exp_Power_2_B() {
	fmt.Print("Enter a Valid Number: ")
	var number2, exp, powerNum float64
	fmt.Scanln(&number2)
	fmt.Println("Please Enter a Exponential Number: ")
	fmt.Scanln(&exp)
	powerNum = math.Pow(number2, exp)
	fmt.Println("Ourput is: ", powerNum)
}

func AdditionOfArray_3_A() {
	array_1 := [3]int{5, 15, 25}
	array_2 := [3]int{10, 20, 30}
	var array_3 [3]int

	//Addition of two array into 3rd array
	for i := 0; i < len(array_1); i++ {
		array_3[i] = array_1[i] + array_2[i]
	}

	fmt.Print("Sum Of Two Array is: ")

	for j := 0; j < len(array_3); j++ {
		fmt.Printf("%d ", array_3[j])
	}
}

func MultiplicationOfArray_3_B() {
	array_1 := [3]int{1, 2, 3}
	array_2 := [3]int{10, 20, 30}
	var array_3 [3]int

	//Addition of two array into 3rd array
	for i := 0; i < len(array_1); i++ {
		array_3[i] = array_1[i] * array_2[i]
	}

	fmt.Print("Sum Of Two Array is: ")

	for j := 0; j < len(array_3); j++ {
		fmt.Printf("%d ", array_3[j])
	}
}

func EnterAndReverseArrays_4_A() {
	array_Act := [5]int{10, 20, 30, 40, 50}

	i := 0
	j := len(array_Act) - 1
	for i < j {
		array_Act[i], array_Act[j] = array_Act[j], array_Act[i]
		i++
		j--
	}

	fmt.Println("Reverse Of Arrays is: ", array_Act)

	// array_Act := [5]int{10, 20, 30, 40, 50}
	//var array_Rev [5]int

	/* for i := 0; i > len(array_Act); i++ {
		array_Rev[i] = array_Act[len(array_Act)-i-1]
	}
	fmt.Println("Reverse Of Arrays is: ", array_Rev)

	fmt.Println("Reverse Of Arrays is: ", array_Act) */
}

func SumOfArrays_4_B() {
	var sum int
	array_Act := [5]int{100, 200, 300, 400, 500}

	for i := 0; i < len(array_Act); i++ {
		sum += array_Act[i]
	}

	fmt.Println("Sum Of Arrays is: ", sum)
}

func LengthOfArrays_5_A() {
	array_Act := [5]int{100, 200, 300, 400, 500}

	fmt.Println("Length Of Arrays is: ", len(array_Act))
}

func FirstAndLastElementOfArrays_5_B() {
	array_FirstLast := [5]int{10, 20, 30, 40, 50}

	// Printing the Array
	fmt.Printf("Given Arrays is: %v\n", array_FirstLast)

	// Accessing zeroth index
	// i.e. first element
	first := array_FirstLast[0]

	// Printing first element
	fmt.Printf("First Element Of an Arrays is: %d\n", first)

	// Accessing length(slice)-1
	// index i.e. last
	// element
	last := array_FirstLast[len(array_FirstLast)-1]

	// Printing last element
	fmt.Printf("Last Element Of an Arrays is: %v\n", last)
}
