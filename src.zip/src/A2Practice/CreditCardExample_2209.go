package A2Practice

/*func ValidateCreditCardNumber() {
	// Credit Card Number length is 16 digit
	// First Digit Should Not be Zero
	// All the 16 characters are digit(No Blank Space, No other character)
	var ccNumberStr string
	intValue := 0
	var employees []string

	fmt.Print("Enter 16 Digit Credit Card Number: ")
	fmt.Scan(&ccNumberStr)

	_, err := fmt.Sscan(ccNumberStr, &intValue)
	fmt.Println(intValue, err, reflect.TypeOf(intValue))

	fmt.Println("Welcome to Assessment - 2")
	var strName string = ""
	var employees []string

	fmt.Print("Enter Employee Name: ")
	fmt.Scan(&strName)
	for strName != "Done" {
		employees = append(employees, strName)

	}
	fmt.Print("Employee Names: ", employees)
}*/

func Creditcardcheck() {

	var creditcard string

	var countdigit int

	fmt.Print("Enter the credit card")

	fmt.Scan(&creditcard)

	if len(creditcard) != 16 || creditcard[0] == '0' {

		fmt.Println("The credit card is invalid because it starting either with 0 or length is not equal to 16")

	} else {

		for i := 0; i < len(creditcard); i++ {

			if unicode.IsDigit(rune(creditcard[i])) {
				countdigit++
			}
		}
		if countdigit != 16 {

			fmt.Println("The card is invalid because it has characters")

		} else {
			fmt.Println("The card is valid")
		}
	}
}
