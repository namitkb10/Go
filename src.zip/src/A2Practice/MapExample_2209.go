package A2Practice

import "fmt"

//write a program to read to ask the user to enter employeeid if the user does not enter employee Id -999 then ask the user to enter employee name.

//you need to keep on asking the user to enter  employyeId an name to enter -999 add the employye id an name to the map where employyee id= key and name= value

//and display all the name and iD

func MapExample() {

	var name string
	var id int
	var mapExample = make(map[int]string)
	fmt.Print("Enter Employee ID: ")
	fmt.Scan(&id)

	for id != -999 {

		fmt.Print("Enter Employee Name")

		fmt.Scan(&name)

		mapExample[id] = name

		fmt.Println("Enter Employee ID")

		fmt.Scan(&id)

	}
	fmt.Print(mapExample)
}
