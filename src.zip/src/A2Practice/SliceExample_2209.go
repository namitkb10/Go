package A2Practice

import "fmt"

func EmployeeName_Slice() {
	// Take User Input and keep on entering untill Done is not entered
	// Using Slice Concepts

	var strName string = ""
	var employees []string

	fmt.Print("Enter Employee Name: ")
	fmt.Scan(&strName)
	for strName != "Done" {
		employees = append(employees, strName)

	}
	fmt.Print("Employee Names: ", employees)

}
