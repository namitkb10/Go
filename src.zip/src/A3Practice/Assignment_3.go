package A3practice

import "fmt"

func OddNumberArray_1_B() {
	fmt.Println("Hello Assignment-3")
	var sum int
	array_OddEven := [11]int{10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20}
	//array_Odd
	// array_Even

	for i := 0; i < len(array_OddEven); i++ {
		if array_OddEven[i]/2 == 0 {
			fmt.Println("Number, , is Even")
		} else {
			fmt.Println("Number, , is Odd")
		}
		sum += array_Act[i]
	}
}
