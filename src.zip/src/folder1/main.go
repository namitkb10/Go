package main

import (
	"fmt"

	"example.com/src/folder2"
)

func main() {
	fmt.Println("Hello GO")
	folder2.StringDisplay()
}
