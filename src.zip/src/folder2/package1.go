package folder2

import "fmt"

func StringDisplay() {
	fmt.Println("Strings Displayed")
}
