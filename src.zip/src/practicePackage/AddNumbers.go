package practicePackage

import "fmt"

func Addition() {
	c := 20 + 30
	fmt.Println(c)
}

func Substraction() {
	d := 20 - 10
	fmt.Println(d)
}
