package main

import (
	"fmt"
	"strings"

	"example.com/src/practicePackage"
)

//import "example.com/src/subFolder"

func main() {
	fmt.Println("Welcome to 1st GO String")
	practicePackage.Addition()
	practicePackage.Substraction()
	fmt.Printf("\n")
	fmt.Println(strings.HasPrefix("Namit", "Na"))
	fmt.Println(strings.HasPrefix("Namit", "A"))
	fmt.Println(strings.HasPrefix("Namit", ""))
	fmt.Printf("\n")
	fmt.Println(strings.HasSuffix("Namit", "it"))
	fmt.Println(strings.HasSuffix("Namit", "p"))
	fmt.Printf("\n")
	fmt.Println(strings.Index("go went gone", "go"))
	fmt.Println(strings.LastIndex("go went gone", "go"))
	fmt.Println(strings.LastIndex("go went gone", "none"))
	// Hello()
	// hello()
	fmt.Printf("\n")
	fmt.Println(strings.Compare("a", "b"))
	fmt.Println(strings.Compare("a", "a"))
	fmt.Println(strings.Compare("b", "a"))
}
