package main

import "fmt"

func Hello() {
	fmt.Println("Inside secondString print UpperCase Hello Function")
}

func hello1() {
	fmt.Println("Inside secondString print LowerCase Hello Function")
}
