package main

import "fmt"

func runeEx() {
	var a1 rune
	a1 = 'A'
	fmt.Printf("%c %[1]d", a1)
}
